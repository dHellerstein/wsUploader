<?php
// This is the "target handler" for wsUploader. It recieves files sent by a  "source" server
// (that is using wsUploader.php).
// For installation details, see wsUploader_desc.htm
// Note: for better results you may need to tweak  the postMaxSize and  upload_max_filesize in php.ini
//       (perhaps to 6 or 8M)

$targetDirs=[];  // do NOT change this

// =========== user changable variables  ---------------

// $targetDirs['aSourceNickName']='aFullyQualifiedDirectory' ; // you can have multiple entries under targertDirs
$targetPwd="" ;                   // the source server's targetPassword must match this
$targetNickname="";                // used for informational purposes


// --------- end of user changable variables


use wSurvey\utilsP as utils ;
use wSurvey\getJson as getJs ;
ob_start()  ;

$rootdir=$_SERVER['DOCUMENT_ROOT'] ;
$nowtime=time();
$curDir=getcwd();
$webRoot=dirname($_SERVER['PHP_SELF']);
$targetServerName=$_SERVER['SERVER_NAME'];

require_once($curDir.'/wsurvey.getJson.php');
require_once($curDir.'/wsurvey.utilsP.php');

$res=['problem'=>false,'targetServerName'=>$targetServerName,'freeSpace'=>false];

$action= getJs\readvar('todo',false);
$theSource=getJs\readvar('source','');

// note: targetDirs[theSource] is assumed to exist (was checked in step 'check')

if ($action=='basic') {
   $targetDir=$targetDirs[$theSource];
   $targetDir=str_replace('\\','/',$targetDir );
   $targetDir=rtrim($targetDir,'/');

   $targetDirUse=realpath($targetDir);
   if (!is_dir($targetDirUse) ) {
      $res['problem']="No such target directory: $targetDir. This script (".$_SERVER['SCRIPT_FILENAME'].") needs to be modified.";
   } else {
     $res['totalSpace']=disk_total_space($targetDirUse);
     $res['freeSpace']=disk_free_space($targetDirUse);
     $res['targetDir']=$targetDirUse;
     $res['targetNickname']=$targetNickname;
     $res['targetDir_subdirs']=utils\get_subdir_list($targetDirUse);
  }

  $res['memLimit']= utils\getBytes(ini_get('memory_limit'));
  $res['postMaxSize']= utils\getBytes(ini_get('post_max_size'))  ;
  $res['upload_max_filesize']= utils\getBytes(ini_get('upload_max_filesize'));

  getJs\jsonReturnContent($res);  // this exits

}

// =============
// create directories
if ($action=='setDirs') {
 $logonUse=getJs\readVar('logon','');

 session_id($logonUse);
 session_start() ;
 if (!isset($_SESSION['uploaderS_logon'])) {
      print "Logon required (setDirs) -- source and target servers must use same password ";
      exit;
  }
  $dirList0=getJs\readVar('dirListUse',[]);
  $dirList1=explode(',',$dirList0);
  sort($dirList1,SORT_STRING );
  $res1=['fail'=>[],'exist'=>[],'create'=>[]];

   $targetDir=$targetDirs[$theSource];
   $targetDir=str_replace('\\','/',$targetDir );
   $targetDir=rtrim($targetDir,'/');

   $targetDirUse=realpath($targetDir);

  foreach ($dirList1 as $ii=>$adir0) {

     if (strpos($adir0,'..')!==false) {
         print "Illegal directory name (contains ..) ";
         exit;
     }
     $adir=str_replace('\\','/',$adir0);
     $adir=trim($adir,'/');
     $dodir= ($targetDirUse.'/'.$adir);
     if (is_dir($dodir)) {
        $res1['exist'][]=$adir0;
     } else {
        $amess="creating: $adir0 ($dodir)" ;
        $qok= @mkdir($dodir,0777,true);
        if (is_dir($dodir)) {
          $res1['create'][]=$adir0;
        } else {
          $res1['fail'][]=$adir0;
        }
     }    // if isdir
   }   // firesch
   $a1=implode(',',$res1['exist']);
   $a2=implode(',',$res1['create']);
   $a3=implode(',',$res1['fail']);
   $a4=$a1.';'.$a2.';'.$a3;        // exist ;create ;fail
   print $a4 ;
   exit;
}

//====== check if files already exists
if ($action=='checkFiles') {
 $logonUse=getJs\readVar('logon','');

// $overwrite=getJs\readVar('overwrite','0');  // not used -- return info that wsUPloader _actions will work with
// $overwriteOld=getJs\readVar('overwriteOld','0');
// if ($overwrite==0) $overwriteOld=0;

 session_id($logonUse);
 session_start() ;
 
 $targetDir=$targetDirs[$theSource];
 $targetDir=str_replace('\\','/',$targetDir );
 $targetDir=rtrim($targetDir,'/');

 $targetDirUse=realpath($targetDir);

 if (!isset($_SESSION['uploaderS_logon'])) {
      print "Logon required (setDirs) -- source and target servers must use same password ";
      exit;
  }
  $fileListUse0=getJs\readVar('fileListUse',[]);
  $fileListUse=explode(',',$fileListUse0);
  $existFile=[]; $notExistFile=[]; $existFileOld=[];

  foreach ($fileListUse as $ii=>$afile0) {
     $arf=explode(';',$afile0);
     $jorig0=$arf[0];
     $arf2=explode(' ',$jorig0);
     $jorig=trim($arf2[0]);
     $mdateSource=trim($arf2[1]);
     $afile=$arf[1];
     $dofile= ($targetDirUse.'/'.$afile);
     if (is_file($dofile)) {
         $mdate=filemtime($dofile);
         if ( ($mdateSource-$mdate)>2) {   // filemtime has iffy resolution
            $existFileOld[]=$jorig;
        } else {
            $existFile[]=$jorig;
        }

     } else {
         $notExistFile[]=$jorig;
     }
  }
   $a0=implode(',',$existFile);
   $a1=implode(',',$existFileOld);
   $a2=implode(',',$notExistFile);
   print  $a0.';'.$a1.';'.$a2 ;  //  exist;existOld;notexist
   exit;
 }

// return a salt to the source (for use in password enctyption)
if ($action=='check') {

  if (count($targetDirs)<1 || trim($targetPwd)=='' ||  trim($targetNickname)=='') {
    print  "targetDirs or targetPwd or targetNickname have not been specified. This script (".$_SERVER['SCRIPT_FILENAME'].") needs to be modified.";
    exit;
  }

  if (!array_key_exists($theSource,$targetDirs)){
      print "Unrecognized source server ($theSource). This script (".$_SERVER['SCRIPT_FILENAME'].") needs to be modified." ;
      exit;
  }
  $asource=getJs\readVar('source',false);
    $time=time();
    $arand=substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"), 10, 10);
    $asalt= $time."_".$arand ;
   print "$asource,$asalt";
   exit;
}

// validation  from source
if ($action=='check2') {

  session_start() ;
  $sentPwd=getJs\readVar('pwdHash','');
  $asalt=getJs\readVar('salt','');
  $sourceNickName=trim(getJs\readVar('source',''));

  $goo=explode('_',$asalt);
  $atime=$goo[0] ;
  $nowTime=time();
  $adiff=abs($nowTime-$atime);
  if ($adiff>100) {    // 100 second lifespan for this hashed password
     print "0,timeout  ";
     exit;
  }
  $myHash=md5($targetPwd.'_'.$asalt);
  if ($sentPwd==$myHash) {
   //  $useLogon='uploaderS_'.$sourceNickName;
    $useLogon='uploaderS_logon';
     $_SESSION[$useLogon]= $atime ;
     $ss=session_id();
     print "1,$sourceNickName,$ss,$targetNickname";
     exit;
  }
  print "0,mismatch" ;
  exit;
}



// -----------
// get a zip file and save its contents to dir

if ($action=='saveSetZip') {
 $logonUse=getJs\readVar('logon','');
 $sayFile=getJs\readVar('sayFile','');
 session_id($logonUse);
 session_start() ;
 if (!isset($_SESSION['uploaderS_logon'])) {
      print "Logon required -- source and target servers must use same password ";
      exit;
  }
   $targetDir=$targetDirs[$theSource];
   $targetDir=str_replace('\\','/',$targetDir );
   $targetDir=rtrim($targetDir,'/');

  $targetDirUse=realpath($targetDir);
  $ufileZip=$_FILES['fileData']['tmp_name'];


   $zip = new \ZipArchive(); // Load zip library
   $res=$zip->open($ufileZip  );
   $nfiles=$zip->numFiles;
   $acomment=$zip->comment;
   print "Saving $sayFile (<em>$acomment</em>) " ; // with $nfiles files ";

     for ($jz=0;$jz<$nfiles;$jz++) {
      $garg=$zip->statIndex($jz);
      $fileName=trim($garg['name']);
      if (strpos($fileName,'..')!==false) {
         print '<br>Illegal fileName (contains ..) ';
         continue ;
      }
      $fileNameSave=str_replace('\\','/',$fileName );
      $fileNameSave=trim($fileNameSave,'/');
      $fileNameSave= ($targetDirUse.'/'.$fileNameSave);

      $fileMtime=$garg['mtime'];

      $gstuff=$zip->getFromIndex($jz);
      $qq=file_put_contents($fileNameSave,$gstuff);
       print "<br> $fileName: $qq " .' ('.date('Y-M-d H:i ',$fileMtime).')';
      touch($fileNameSave,$fileMtime);

    }
    exit;
}



// -----------
// get a piece of file and save its contents to dir

if ($action=='saveSetPiece') {

   $logonUse=getJs\readVar('logon','');
    $sayFile=getJs\readVar('sayFile','');
   session_id($logonUse);
   session_start() ;
   if (!isset($_SESSION['uploaderS_logon'])) {
      print "Logon required -- source and target servers must use same password ";
      exit;
  }

   $targetDir=$targetDirs[$theSource];
   $targetDir=str_replace('\\','/',$targetDir );
   $targetDir=rtrim($targetDir,'/');

  $targetDirUse=realpath($targetDir);
  $upieceZip=$_FILES['fileData']['tmp_name'];

  $piece=getJs\readVar('piece',0);
  $npieces=getJs\readVar('npieces',0);
   $sayFile=trim(getJs\readVar('sayFile',''));
   if (strpos($sayFile,'..')!==false) {
       print "Error: illegal file name (contains ...) ";
       exit;
   }

  $fileNameSave=$targetDirUse.'/'.$sayFile;

  $zip = new \ZipArchive(); // Load zip library
  $res=$zip->open($upieceZip);
  $garg=$zip->statIndex(0);
  $fileMtime=$garg['mtime'];
  $gstuff=$zip->getFromIndex(0);
  $klen=strlen($gstuff);
  if ($piece==1)  {
      $jadd=file_put_contents($fileNameSave,$gstuff);
      print utils\custom_number_format($jadd)." (first of $npieces) saved to $sayFile " ;
  } else {
      $jadd=file_put_contents($fileNameSave,$gstuff,FILE_APPEND);
      if ($piece==$npieces) {
           touch($fileNameSave,$fileMtime);
           $sayDate=date('Y-M-d H:i ',$fileMtime);
           print utils\custom_number_format($jadd)." (last of $npieces) saved to $sayFile ($sayDate)" ;
      } else {
          print utils\custom_number_format($jadd)." ($piece/$npieces) saved to $sayFile " ;
      }
  }

  exit;

}

getJs\jsonReturnError("No such action: $action ");


exit ;  // should never get here
?>