<?php
session_start() ;
//  Uploader.
// This is the source side. It provides the user interface, and   accesses the "source" directory to
// find and select files to upload to the target.
//
// For installation details, see wsUploader_desc.htm

// ----- -------- user changable variables. The first four MUST be specified.  -----------------------

$sourceNickname="";            // used to tell the target server where to saved uploaded files
$sourceDir="";                 // the default directory to find files (for uploading)
$targetUri=" ";                // the url to the target server
$targetPassword=""  ;          // the password (must match the password specified on the target server)

$userSelectSourceDir=1 ;                         // if 0, the sourceDir can NOT be changed from the browser
$skipSubdirs='trash,tmp,temp,$RECYCLE.BIN'  ;    // case insensitive list of subdirectories to ksip
$skipExts='tmp,temp,$,old, sf,arc' ;            // case insensitive list of file extensions to skip, spaces are not stripped

$sourceNicknamesAllowed='';    // optional: if not '' allow this source to connect using different sourceNicknames

// ------ ------ END of  user chAngable variables -----------------------

use wSurvey\utilsP as utils ;
use wSurvey\getJson as getJs ;
ob_start()  ;

$rootdir=$_SERVER['DOCUMENT_ROOT'] ;
$nowtime=time();
$curDir=getcwd();
$webRoot=dirname($_SERVER['PHP_SELF']);
$sourceServerName=$_SERVER['SERVER_NAME'];

$aa=function_exists('curl_exec');
if ($aa===false) {
    print "Sorry: this source server ($sourceServerName) does not support CURL. ";
    exit;
}

if (!extension_loaded('zip'))  {
    print "Sorry: this source server ($sourceServerName) does not support ZIP file creation ";
    exit;
}

if (trim($sourceDir)=='' || trim($targetUri)=='' ||  trim($sourceNickname)=='' ||  trim($targetPassword)=='') {
  print "You must specify the sourceDir, targetUri, targetPassword, and sourceNickname parameters. This script (".$_SERVER['SCRIPT_FILENAME'].") needs to be modified.";
  exit;
}

// clumsy but works -- change to a different sourceNickname (account)
$altNickName= (array_key_exists('altNickName',$_REQUEST)) ? $_REQUEST['altNickName'] : '';
if ($altNickName!='') {
   $tt = preg_split('/[\ \n\,]+/', $sourceNicknamesAllowed);
   if (!in_array($altNickName,$tt)) {
       print "<br>alternative source nickname ($altNickName) not available ";
       exit;
   }
   $sourceNickname=$altNickName;
}

// validate with target server
    $request = curl_init($targetUri);
   $data=['todo'=>'check','source'=>$sourceNickname];
   curl_setopt($request, CURLOPT_POST, true);  // send a file
   curl_setopt($request,CURLOPT_POSTFIELDS,$data);
   curl_setopt($request, CURLOPT_RETURNTRANSFER, true);
   $ares= curl_exec($request);
   curl_close($request);

   $tt=explode(',',$ares);
   if (count($tt)<2) {  // an error
       print $ares;
       exit;
   }
   $asalt=$tt[1];
   $pwd1=$targetPassword.'_'.$asalt;
   $pwdMd5=md5($pwd1);
   $data=['todo'=>'check2','pwdHash'=>$pwdMd5,'salt'=>$asalt,'source'=>$sourceNickname];
   $request = curl_init($targetUri);
   curl_setopt($request, CURLOPT_POST, true);  // send a file
   curl_setopt($request,CURLOPT_POSTFIELDS,$data);
   curl_setopt($request, CURLOPT_RETURNTRANSFER, true);

   $ares2= curl_exec($request);

   curl_close($request);

   $goox=explode(',',$ares2);
   if ($goox[0]==0) {  // error
     print "Unable to validate with the target server (using $targetUri): ".$goox[1] ;
     print "<br> $ares2 ";
     exit;
   }
   $targetNickName=$goox[3];
   $logonString=$goox[2];

   $_SESSION['uploaderC_logon']=$logonString;

   $_SESSION['uploaderC_uploadInfo']=[];  ;

// ==== validation for tarkeg server .... okay!

require_once($curDir.'/wsurvey.getJson.php');
require_once($curDir.'/wsurvey.utilsP.php');

$sourceServerName=$_SERVER['SERVER_NAME'];

 if (!is_dir($sourceDir)) {
   print "<br>Error: the default source directory (<tt>$sourceDir</tt>) does not exist. Please modify ".$_SERVER['SCRIPT_FILENAME'];
   exit;
 }


// ::::::::::::::: below here is the html displayed to the client :::::::::::::;;
?>
<!DOCTYPE HTML>
<html><head><title>Uploader: client side</title>
<meta charset="utf-8">

<script type="text/javascript">
// ------------- user changable variables -----------------------

</script>

<link rel="stylesheet" type="text/css" href="wsUploader.css" />

<script type="text/javascript" src="jquery-3.6.0.min.js"></script>
<script type="text/javascript" src="wsurvey.utils1.js">  </script>
<script type="text/javascript" src="wsurvey.getJson.js"></script>

<script type="text/javascript">
// variables declared above (in .php )

 <?php
    print "var sourceDir='".$sourceDir."' ; \n ";
    print "var userSelectSourceDir='".$userSelectSourceDir."' ; \n ";
    print "var targetUri='".$targetUri."' ; \n ";
    print "var sourceServerName='".$sourceServerName."' ; \n ";
    print "var sourceNickname='".$sourceNickname."' ; \n ";
    print "var skipSubDirs='".$skipSubdirs."' ; \n ";
    print "var skipExts='".$skipExts."' ; \n ";
    print "var targetNickName='".$targetNickName."' ; \n ";
    print "var sourceNicknamesAllowed='".$sourceNicknamesAllowed."' ; \n ";

  ?>

  let spinners=['Bubble-1.5s-38px.gif','Spin-1s-200px.gif','spinner-icon-gif-1.jpg','spinner-icon-gif-25.jpg'];

  $(document).data('basics',{});
  window.onload=init ;


function init(x) {
  sourceNicknamesAllowed=jQuery.trim(sourceNicknamesAllowed);
  if (sourceNicknamesAllowed!='') {
    let tt=sourceNicknamesAllowed.split(/[ ,]+/).filter(Boolean);    // https://stackoverflow.com/questions/10346722/how-to-split-a-string-by-white-space-or-comma
    let ss={};
    for (var j1 in tt) {
        att=tt[j1];
        ss[att]=1;
    }
    sourceNicknamesAllowed=ss;
    $('#allowSwitch').show();
  } else {
      sourceNicknamesAllowed=false;   // do not show the swithc button
  }

   let adata={'todo':'basic','sourceServerName':sourceNickname,'source':sourceNickname};
   let ss1s=sourceServerName+'&nbsp;&nbsp;[<span style="font-style:oblique;padding:3px" title="Source nickname">'+sourceNickname+'</span>] ' ;
  $('#sourceServerName').html(ss1s)

$('#iSkipSubdirs').val(skipSubDirs);
$('#iSkipExts').val(skipExts);
 wsurvey.getJson.setErrFunc('doError');

  wsurvey.getJson.get(targetUri,adata,initC,'get limits');

}
function initC(sresponse,origData,otherArgs2) {
  stuff=wsurvey.getJson.content(sresponse,0,'in initc');
  let gotProblem=stuff['problem'];

  if (gotProblem!==false) {
     $('#problem').html(gotProblem).show();
  }

  let targetSpecs={'serverName':stuff['targetServerName'],'freeSpace':stuff['freeSpace'],'dir': stuff['targetDir'],'targetUri':targetUri};
  targetSpecs['nickName']=targetNickName ;

  let stuffUse={'targetSpecs':targetSpecs};

  let limits={'memLimit':stuff['memLimit'],'postMaxSize':stuff['postMaxSize'],'upload_max_filesize':stuff['upload_max_filesize']};
  stuffUse['targetLimits']=limits;
  $(document).data('basics',stuffUse);

  $('#sayLimit_postMaxSize').html(wsurvey.addComma(stuff['postMaxSize']));
  $('#sayLimit_maxFileSize').html(wsurvey.addComma(stuff['upload_max_filesize']));

  let a1=wsurvey.addComma(stuff['targetDir'])+'  w/ '+wsurvey.makeNumberK(stuff['freeSpace'])+ ' bytes available (of '+wsurvey.makeNumberK(stuff['totalSpace'])+')';

  $('#say_targetDir').html(a1);
  let sayx='<span title="target: servername ">'+stuff['targetServerName']+'</span> <span title="target: nickname" style="font-style:oblique">'+targetNickName+'</span>';
  $('#say_targetServer').html(sayx);
 let oof1='';
 oof1+='<ul class="linearMenu">';
   oof1='<li><b>Existing subdirectories on target ...</b>';
 for (var oy in stuff['targetDir_subdirs']) {
     let oof2=stuff['targetDir_subdirs'][oy];
     oof1+='<li class="linearMenuLi">'+oof2+'</li> ';
  }
  oof1+='</ul>';

  $('#say_targetDir_subdirs').html(oof1);

  let esd= $('#sourceDir');
  esd.val(sourceDir);  // set default in the input field
   if (userSelectSourceDir!=1) {
      esd.prop('disabled',true);
      esd.prop('readonly',true);
      esd.attr('title','Source directory can not be changed from browser ');
   }


}

//==================
// get info on target dir
function reviewTarget(athis) {
 $('#say_targetDir_subdirs').css({'height':'2.5em'});
 $('#divDirsSelected').html('');
 $('#uploadResults').html('');
 $('#divDirsHeader').html('');

   ethis=wsurvey.argJquery(athis);
//   let atargetDir=$('#sourceDir').val();                                  
   let aSourceDir=$('#sourceDir').val();

   let skipSubDirsUse=jQuery.trim($('#iSkipSubdirs').val());
   if (skipSubDirsUse.indexOf('..')>-1) {
       alert("Error: .. can not be a skipSubDir ");
       return 0;
   }
   let skipExtsUse=jQuery.trim($('#iSkipExts').val());

   let adata={'todo':'reviewSourceDir','source':sourceNickname, 'dir':aSourceDir,'resume':0,'skipSubDirs':skipSubDirsUse,'skipExts':skipExtsUse };
   let irand=parseInt(4*Math.random());
   let aspinner=spinners[irand];

   let aimg='<img src="'+aspinner+'" height="20" width="20"> ';
   let adiv='<div class="reviewTargC">'+aimg  ;
   adiv+=" Retrieving content of targetDir: "+aSourceDir+' &hellip; <span id="iPleaseWait" style="font-style:oblique">please wait</span>';
   adiv+='</div>';

  $('#sourceDirInfo').html(adiv);

   wsurvey.getJson.get('wsUploaderC_actions.php',adata,reviewTargetC,'get dir/ file info start');
}

/// callback ,,, and possibly tiemout/resume!
function reviewTargetC(sresponse,origData,otherArgs2) {

  let stuff=wsurvey.getJson.check(sresponse,0,'in reviewTargetC');
  if (stuff===false) return 0;

  let gotProblem=stuff['problem'];
  if (gotProblem!==false) {
      $('#sourceDirInfo').html('');
     $('#problem').html(gotProblem).show();
     return 1;
  }
  $('#problem').hide() ; // no problem!

  if (stuff['resume']===false) {  //done
    let targDir=origData['dir'];
    let scontent=stuff['content'] ;
 
    let totBytes=scontent['totBytes'];
    let aa="Summary of <u>"+targDir+'</u>: '+scontent['totDirs']+' directories, '+wsurvey.addComma(scontent['totFilesUse'])+' files with '+wsurvey.makeNumberK(totBytes)+' bytes';
    aa+='. <b>Next step</b>: <input type="button" id="openCopyMenu" value="Select directories to upload" title="Pick, and choose, details on what is to be copied" onClick="copyStep1(this)">';
    scontent['dir']=origData['dir'];
    scontent['serverName']=sourceServerName;
    let dd=$(document).data('basics');
    dd['sourceSpecs']=scontent;
    $(document).data('basics',dd);

    let freeSpace=dd['freeSpace'];
    if ((freeSpace*0.95)<scontent['totBytes']) {
      aa+='<br><span style="background-color:yellow">Warning: freespace on target ('+wsurvey.makeNumberK(freeSpace)+') ';
      aa+=' is less than (or close to) the required bytes ('+wsurvey.makeNumberK(totBytes)+')';
    }

    $('#sourceDirInfo').prepend(aa+'<hr width="30%">' );
    let eoof= $('.reviewTargC');
    eoof.css({'opacity':'0.4'});
    let ewait=$('#iPleaseWait');
    ewait.html('Done!');
    let eparent=ewait.closest('#sourceDirInfo');
    let espins=eparent.find('img');
    espins.hide();

    return 1;
  }

// if here, a timeout.. so resume (but first report last status)
   let irand=parseInt(4*Math.random());
   let aspinner=spinners[irand];
   let aimg='<img src="'+aspinner+'" height="20" width="20"> ';
   let adiv='<div class="reviewTargC">'+aimg+stuff['content']+'</div>';
   $('#sourceDirInfo').append(adiv);

   let adata=origData;
   adata['resume']=1;
   wsurvey.getJson.get('wsUploaderC_actions.php',adata,reviewTargetC,'get dir/ file info');

}

//============
// error handler
function doError(amess) {
 $('#sourceDirInfo').html(amess);
}

//===============
// create a table of directories to be uploaded
function copyStep1(athis) {
  let aa=$(document).data('basics');
  let adata={'todo':'menu1','source':sourceNickname}    // uses stuff stored in di
  wsurvey.getJson.get('wsUploaderC_actions.php',adata,copyStep1c,'get menu 1 (dirs found)');
}

//--
// display the table of directrores to be uploaded
function copyStep1c(sresponse,origData,otherArgs2) {
   stuff=wsurvey.getJson.check(sresponse,0,'in copyStep1c');
   if (stuff===false) return 1;
   goo=stuff['content'];
   if (stuff===false) return 0;
   $('#sourceDirInfoResults').html( goo);
   $('#divDirsSelected').on('click',copyStep2a)
}

//=======
// retain the checked directories to be uploaded
function copyStep2a(evt) {
    let ethis=wsurvey.argJquery(evt);
    if (ethis.attr('name')!=='useThisDir') return 1;  // only if clicked in checkbox

    let e2=$('#selectedDirsHeader');
    let jDirs=parseInt(e2.attr('data-dirsnow'));
    let jFiles=parseInt(e2.attr('data-filesnow'));
    let jBytes=parseInt(e2.attr('data-bytesnow'));

    let aFiles=parseInt(ethis.attr("data-files"));
    let aBytes=parseInt(ethis.attr("data-bytes"));

    let imult= (ethis.prop('checked')) ? 1 : -1 ;

    jDirs=jDirs+(imult);
    jFiles=jFiles+(imult*aFiles);
    jBytes=jBytes+ (imult*aBytes);
    $('#selectedForCopy').html(jDirs+' / '+ wsurvey.addComma(jFiles)+' / '+ wsurvey.makeNumberK(jBytes));

    e2.attr('data-dirsnow',jDirs);
    e2.attr('data-filesnow',jFiles);
    e2.attr('data-bytesnow',jBytes);

}

//=======================
// start uploading
// step1 : create (if necessary) directories on target
function startCopying(athis) {
   let e1=$('#sourceDirInfo');
   let e2=e1.find('[name="useThisDir"]');
   let e3=e2.filter(':checked');

   let eover=$('#uploadOverwrite');
   let doOver= (eover.prop("checked")) ? 1 : 0 ;

   let eoverold=$('#uploadOverwriteOld');
   let doOverOld=(eoverold.prop("checked")) ? 1 : 0 ;

   epause1=$('#uploadPause1');
   let doPause1= (epause1.prop('checked')) ? 1  : 0 ;

  ego=$('#iGoButton');
  ego.prop('disabled',true);
  ego.css({'opacity':'0.5'});
  let eoc=$('#openCopyMenu');
  eoc.prop('disabled',true);
  eoc.css({'opacity':'0.5'});
  $('.reviewTargC').hide();
 $('#otherOptions').hide();


   let totFiles=0,totBytes=0;
   let doems=[];
   for (var j=0;j<e3.length;j++) {
      let e3a=$(e3[j]);
      let jbytes=e3a.attr('data-bytes');
      totBytes+=jbytes;
      let jfiles=e3a.attr('data-files');
      totFiles+=jfiles;
      let apath=e3a.attr('data-path');
      doems.push(apath);
   }
   let dd=Date.now();
   let basics=$(document).data('basics');
   let adata={'todo':'senditStep1','source':sourceNickname,'dirs':doems,'basics':basics,'pause1':doPause1,
              'overwrite':doOver,'overwriteOld':doOverOld,'startTime':dd}    // uses stuff stored in di
    wsurvey.getJson.get('wsUploaderC_actions.php',adata,startCopyingC,'startCopying 1 ');
}

// ==
//  step2 : check for existing files on atraget
function startCopyingC(sresponse,origData,otherArgs2) {
   stuff=wsurvey.getJson.check(sresponse,0,'in copyStep1c');
   if (stuff===false) return 1;
   goo=stuff['content'];
   $('#uploadResults').html(goo);

// now check for existence of files
  let adata={'todo':'senditStep2','source':sourceNickname,'pause1':origData['pause1'],
            'overwriteOld':origData['overwriteOld'],'overwrite':origData['overwrite'],'startTime':origData['startTime'] }

  wsurvey.getJson.get('wsUploaderC_actions.php',adata,startCopyingD,'startCopying 2 ');

}

//======
//  step 3: create list of "sets" and "bigs"
function startCopyingD(sresponse,origData,otherArgs2) {
   stuff=wsurvey.getJson.check(sresponse,0,'in copyStep1d');
   if (stuff===false) return 1;
   goo=stuff['content'];
  $('#uploadResults').append('<hr>'+goo);

  let adata={'todo':'senditStep3','source':sourceNickname,'startTime':origData['startTime'],'pause1':origData['pause1'] }    // start uploading

  wsurvey.getJson.get('wsUploaderC_actions.php',adata,startCopyingE,'startCopying D ');

}
//=========
// step 4, start sending the sets
function startCopyingE(sresponse,origData,otherArgs2 ) {

   stuff=wsurvey.getJson.check(sresponse,0,'in copyStep1e');
   if (stuff===false) return 1;
   goo=stuff['content'];
   $('#uploadResults').append('<hr>'+goo);
   let mm='';
   mm+=' <span id="epsSendingStatus" style="font-size:90%;font-style:oblique;padding:3px;margin:3px 5px 3px 3px;border-right:1px solid gray" title="elapsed time (hr:min:sec)"></span> ';
   if (origData['pause1']==1) {
      mm+='<input type="checkbox" checked value="1" id="pauseSending" title="Pause the upload">';
   } else {
      mm+='<input type="checkbox" value="1" id="pauseSending" title="Pause the upload">';
   }
   mm+='<label for="pauseSending" title="Pause the uploading">Pause</label> | ';
   mm+='<button  style="display:none;font-size:120%;color:green" id="resumeSending" onClick="doUploadResume(this)" title="click to resume sending (after a pause)">Resume!</button> ';
   mm+='<input type="checkbox" value="1" id="stopSending" title="halt upload">';
   mm+='<label for="stopSending" title="halt the uploading">Halt the upload</label> | ';
   mm+='<input type="checkbox"   value="1" id="showMore" title="Show more status information">';
   mm+='<label for="showMore" title="Show more status information">Show more</label>';

   mm+=' | <span style="background-color:cyan" id="setSendingStatus">Uploading sets ...</span> |';
   mm+='  <span id="bigSendingStatus" style="background-color:tan">...</span> ';
   $('#divDirsHeader').html('Status ... '+mm+'<br>');

    $('#divDirsSelected').prepend('<hr style="border:2px solid green;border-radius:5px" />');

   let adata={'todo':'senditStep4','source':sourceNickname,'startTime':origData['startTime'] }    // start uploading

   let slug=$('#pauseSending');
   let doPause1=slug.prop('checked');
   let twait=100;
   if (doPause1==0) {
       twait=2000;
       $('#epsSendingStatus').html('Upload will start in 2 seconds ... ');
   }
    window.setTimeout(function() {
       if (slug.prop('checked')) {
         let ehp1=$('#resumeSending');
         ehp1.show();
         let astuff={'function':'pause1','adata':adata };
         ehp1.data('resumeUsing',astuff);
         slug.prop('checked',false);
         return 1;
      }
// no pause at start
       wsurvey.getJson.get('wsUploaderC_actions.php',adata,startCopyingSets,'startCopying E ');
    },twait);  // give 2 seconds for user to click show more

}

// step 4b: send next set
function startCopyingSets(sresponse,origData,otherArgs2,textStatus,jqXHR,again) {   // all args (to deal with again arg used by resume)

   if (arguments.length<6) again=0;
   stuff=wsurvey.getJson.check(sresponse,0,'in copyStep1f');
   if (stuff===false) return 1;

   if (again==0) {
     if ($('#showMore').prop('checked')) {
       let goo=stuff['content'];
       $('#divDirsSelected').prepend('<hr>'+goo);
     }
   }

   let eh=$('#stopSending');
   if (eh.prop("checked")) {
     let qq=confirm("Are you sure you want to halt?");
     if (qq) {
        $('#setSendingStatus').html(' Upload of sets: halted');
        $('#divDirsSelected').prepend('<hr>Upload halted!');
        return 1;
     }
     eh.prop('checked',false);
   }

   let ehp=$('#pauseSending');
   if (ehp.prop('checked')) {
     ehp.prop("checked",false);
     let ehp1=$('#resumeSending');
     ehp1.show();
     let astuff={'function':'sets','sresponse':sresponse,'origData':origData,'otherArgs2':otherArgs2};
     ehp1.data('resumeUsing',astuff);
     return 1;
   }

   let startTime=origData['startTime'];
   let nowTime=Date.now();
   let eps= wsurvey.seconds_toTime(parseInt((nowTime-startTime)/1000));
   $('#epsSendingStatus').html(eps);

   if (stuff['end']==0) {
      let adata={'todo':'senditStep4','source':sourceNickname,'startTime':origData['startTime'] }    // do next set
      wsurvey.getJson.get('wsUploaderC_actions.php',adata,startCopyingSets,'startCopying sets ... ');
      $('#setSendingStatus').html(' Upload set '+stuff['done']+' of '+stuff['nToDo']);
   } else {
      $('#divDirsSelected').prepend('<hr style="border-top:2px solid lime;"/>Upload of sets completed.');
      $('#setSendingStatus').html(' Upload of sets: completed <span style="font-size:70%">'+stuff['report']+'</span>');
      $('#bigSendingStatus').html(' Start upload of big files (in pieces) ... ');
      let adata={'todo':'senditStep5','source':sourceNickname,'startTime':origData['startTime'] }    // start uploading
      wsurvey.getJson.get('wsUploaderC_actions.php',adata,startCopyingBigs,'startCopying sets 2 ');
   }

}

//=======
// step 5:   send  bigs
function startCopyingBigs(sresponse,origData,otherArgs2,textStatus,jqXHR,again) {  // all args (to deal with again arg used by resume)
   if (arguments.length<6) again=0;
   stuff=wsurvey.getJson.check(sresponse,0,'in copyStep1G');

   if (stuff===false) return 1;
   if (again==0) {
     if ($('#showMore').prop('checked')) {
      let goo=stuff['content'];
       $('#divDirsSelected').prepend('<hr>'+goo);
     }
   }

   let eh=$('#stopSending');
   if (eh.prop("checked")) {
       let qq=confirm("Are you sure you want to halt?");
       if (qq) {
          $('#divDirsSelected').prepend('<hr>Upload halted!');
          $('#bigSendingStatus').html(' Halting upload of big files (in pieces) ... ');
         return 1;
       }
       eh.prop('checked',false);
   }

   let ehp=$('#pauseSending');
   if (ehp.prop("checked")) {
     ehp.prop("checked",false);
     let ehp1=$('#resumeSending');
     ehp1.show();
     let astuff={'function':'big','sresponse':sresponse,'origData':origData,'otherArgs2':otherArgs2};
     ehp1.data('resumeUsing',astuff);
     return 1;
   }

   let startTime=origData['startTime'];
   let nowTime=Date.now();
   let eps= wsurvey.seconds_toTime(parseInt((nowTime-startTime)/1000));
  $('#epsSendingStatus').html(eps);

   if (stuff['end']==0) {
      let adata={'todo':'senditStep5','source':sourceNickname,'startTime':origData['startTime'] }    // next big
      let jf=stuff['done']+1;
      let jpiece=stuff['piece']+1;
      let dd='Upload of large files:  piece '+jpiece+' of '+stuff['npieces']+' ('+jf+' of '+stuff['nToDo']+' files)';
      $('#bigSendingStatus').html(dd);
      wsurvey.getJson.get('wsUploaderC_actions.php',adata,startCopyingBigs,'startCopying  bits ... ');
   } else {
      $('#divDirsSelected').prepend('<hr>Upload of bigs completed.');
      $('#bigSendingStatus').html(' Upload of large files completed <span style="font-size:70%">'+stuff['report']+'</span>' );
   }
}

//===================
// resume button (after pause)
//     let astuff={'function':'sets','sresponse':sresponse,'origData':origData,'otherArgs2':otherArgs2;
//     ehp1.data('resumeUsing',astuff);

function doUploadResume(athis) {
   let ethis=wsurvey.argJquery(athis);
   $('#resumeSending').hide();
   let aa=ethis.data('resumeUsing');

// pause @ start
   if (aa['function']=='pause1') {
        let adata=aa['adata']
        wsurvey.getJson.get('wsUploaderC_actions.php',adata,startCopyingSets,'startCopying E (pause @ start) ');
        return 1;
   }

// mid stream pause
   let  sresponse=aa['sresponse'];
   let origData=aa['origData'];
   let otherArgs2=aa['otherArgs2'];
   if (aa['function']=='sets') {
        startCopyingSets(sresponse,origData,otherArgs2,0,0,1) ;   // dont care about textstatus or jqxhr
   } else {
        startCopyingBigs(sresponse,origData,otherArgs2,0,0,1) ;
   }
}

//======
// reconnect using new sourceNIckcname
function reConnect(athis) {
   let enick=$('#aNickName');
   let anick=jQuery.trim(enick.val());

   if (!sourceNicknamesAllowed.hasOwnProperty(anick)) {
      alert('This is alternate sourceNickName ('+anick+') is not available ');
      return 1;
   }
   if (anick=='') return 0;  // ignore empty
   let aloc=$(location).attr('pathname');
   let aloc2=aloc+'?altNickName='+anick
   window.location.href = aloc2

}
// ====================================================================================

</script>


<body>
<div style="background-color:#aabbaa;margin:2px 3em 2px 3em">

<input type="button" value="&#10068;" title="Description" onClick="$('#mainDesc').toggle()" >
 <em>Source</em>:
 <span id="sourceServerName" style="color:blue;background-color:#dfdfdf"> </span>
 <span id="allowSwitch" style="display:none">
 &nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="Switch" title="select a different  sourceNickname" onClick="$('#switchNick').toggle()" >
 <span id="switchNick" style="display:none;background-color:cyan;margin:3px 3px 3px 3em">
      Select  a different sourceNickname: <input type="text" size="20" value="" id="aNickName">
       and <input type="button" value="re-initialize" title="Reconnect with target using this nickname" onClick="reConnect(this)" >
 </span>
 </span>
</div>


<div id="mainDesc" class="cMainDesc">
<input type="button" value="x" title="Close this description " onClick="$('#mainDesc').hide()" >
<a href="wsUploader_desc.htm" title="Click to view the wsUploader documentation" target="desc">Uploader</a>
is used to transfer files -- lots of files -- from a <em>source</em> http: server to a
 <em>target</em> server. This means
 <ul class="thinList">
 <li> The <em>source</em> is a  http: server, that contains files to be uploaded.
 <li> The <em>target</em> is a  http: server, where these files are uploaded to.
 <li> Both source and target must be configured to talk to each other. For security reasons, this means setting parameters
 in <tt>wsUploader.php</tt> and <tt>wsUploaderTarget.php</tt>
 <li>To deal with file size limits, uploading is done in many steps. Some steps upload several small files
 at once, and some steps upload large files in several pieces.
</ul>
Assuming proper configuration ...
(<a href="wsUploader_desc.htm#install" target="desc">the details</a>)

 <ul class="thinList">
<li>Select the <em>source</em> directory. Depending on configuration, this may require editing <tt>wsUploader.php</tt>.
If configured for multiple <em>sourceNicknames</em>, <button>switch</button> can be used to select a <em>sourceNickname</em>.
 <br>The directory, on the <em>target server</em>, where uploaded files are saved directory depends on the sourceNickname.
 It can only be changed by   editing <tt>wsUploaderTarget.php</tt>
<li><button>Read directories on the source</button> to read the directories (under the chosen <em>source</em> directory.
<li><button>More options</button> to change the <tt>skipExts</tt> and <tt>skipSubDirs</tt> lists.
<li>After a few moments (a minute or two if there are thousands of files), a summary of the contents
of the <em>source</em> directory is displayed.
<li> <button>Select directories to upload</button> to choose which directories to upload,
 whether or not to overwrite all (or just older) existing files, or  pause before starting the upload.
<li> Click <button>Start uploading</button> to start the upload. The upload will start in 2 seconds.
<menu class="thinList">
<li> <tt><input type="checkbox">Show more</tt>  :  display details on the uploads -- what files (on
what subdirectories) have been uploaded to the server.
<div style="margin:3px 1em"><b>Caution</b>: if there are a lot of thousands of files, a lot of text is
written -- which can  overload the browser. By default this is <em>not</em> enabled.
</div>
<li> <tt><input type="checkbox">Pause</tt> : pause the upload. A <button>Resume</button> appears -- click it to resume!

<li> <tt><input type="checkbox">Halt the upload</tt>  :  stop the upload.


</menu>
<li>During an upload, the elapsed time, and a summary of upload progress, is continually updated. And you can check the
above buttons at any time.

</ul>

</div>

<div id="problem" style="border:3px solid yellow;display:none;margin:1em"> ... </div>


<div style="border:1px solid blue;margin:1em;padding:3px">
<b>Target</b>:
  <em>server @</em> :<span id="say_targetServer" style="color:blue;background-color:#efdfef"></span>
  / <em>directory</em>: <span  title="Target: directory" id="say_targetDir" style="border-bottom:2px dotted black">...</span>

<span title="Target: server limits " style="padding:1px 5px ;border:1px dashed tan;margin:1px 1em  ">
Limits :
  max post size: <span id="sayLimit_postMaxSize">...</span> |
  max file size: <span id="sayLimit_maxFileSize">...</span>
</span>
</div>

<p>
<div id="say_targetDir_subdirs" class="csay_targetDir_subdirs"> </div>

</div>
Select the <em>source</em> directory to upload from: <input type="text" size="60" value="" id="sourceDir" >
and then <input type="button" value="Read directories on the source" title="view contents of this source-server directory"  onclick="reviewTarget(this)" >
<input type="button" value="More options" title="Click here to set the skipSubDirs and skipExts lists"
  onClick="$('#otherOptions').toggle()">

<div id="otherOptions" style="display:none;margin:0.5em 3em;padding:0.2em;background-color:#dfefdf" >
<table cellpadding="3" rules="rows">
 <tr><td>  <tt>skipSubdirs</tt></td>
 <td> <input title="a CSV of subdirectory names to skip " type="text" size="80" id="iSkipSubdirs"> </td>
 </tr>
 <tr><td>  <tt>skipExts</tt></td>
 <td> <input title="a CSV of file extensions to skip " type="text" size="80" id="iSkipExts"> </td>
 </tr>
</table>
</div>

<div id="sourceDirInfo" style="margin:1em;border:1px solid blue"> </div>
<div id="sourceDirInfoResults" style="margin:1em;border:1px solid blue"> </div>

<ul>


</ul>


</body>
</html>

