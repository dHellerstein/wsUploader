<?php

use wSurvey\utilsP as utils ;

// list all files in all subdirectories, of a path. With resume capablity

// ================================
// begin php functions
//==================
// create a list of subdirs with displayable files (such as images) under the path directory
// todo=makeDirList  calls this
// note: makeDirList_create is ONLY called from dirList_base
// Features:
//      Ignore empty directories.
//      Ignore files that are in skips
//      Use of case insenstive strings for file matching
//
// arguments
//  return [done,dirlist[
//    done = false if resume is on (more work needs to be done). in that case, $resumeStatus has state variables
//    dirList : the final results -- an array of info.
//

function dirList_create($usePath,$skipSubdirs,$skipExts,&$resumeStatus,$timeAllowed) {

   $nowTime=time();

// find all subdirs under path, using a dynamic (semi recursive) metnod

  if (!array_key_exists("dirCheckDone",$resumeStatus)) {        // dirCheckDone won't exist while dirCheck is fully built

// note: no timeout while looking for subdirs of   usepath
    $dirs=dirList_create_getSubToCheck($usePath,$skipSubdirs,$resumeStatus,$nowTime,$timeAllowed);

    if ($dirs===false) {     // false means "need to resume"    -- resumeSTatus has current findings
       $amess='Building dir list: examining directory '.$resumeStatus['nextToDoSubs'].' (of '.$resumeStatus['nCheckSubs'].' currently found)' ;
       $amess.=   ' w/ '.$resumeStatus['nAllFiles'].' files detected  ';
       $amess.=' ('.$resumeStatus['nSubs_root'].' subdirs in the root  directory of '.$usePath.') ';
       return [true,$amess] ;  // not done with dir builiding
    }
// if here ... done (no need to resume)

    $nextInDirsFiles=0;   // the next dir to read files from
    $resumeStatus['dirCheck']=$dirs ;    // final list of directories
    $resumeStatus['nextInDirsFiles']=0;
  } else {       // dircheckdone means "got the dirs, so go to next step)
     $dirs=$resumeStatus['dirCheck'] ;         // current (not final) list of directories found
     $nextInDirsFiles=$resumeStatus['nextInDirsFiles'] ;    // where in dirs to start looking for subdirs
  }


// when here, the full tree of "non skip, non empty" dirs are in dirs. Process eadh of them

// ready to intialize the dirlist!
 if (!array_key_exists('dirList',$resumeStatus) ) {  // dirlist is an expansion of dirCheck (wiith file info, etc)
    $dirList=[];
    $dirList['.']['rootPath']=str_replace('\\','/',$usePath);
    $dirList['.']['totBytes']=0;
    $dirList['.']['totFiles']=0;
    $dirList['.']['totFilesSkip']=0;
    $dirList['.']['totFilesUse']=0;
    $dirList['.']['totDirs']=0;
    $resumeStatus['dirList']= $dirList ;
 } else {       // doResume got here before
     $dirList=$resumeStatus['dirList'];
 }

 $istart=$nextInDirsFiles;
 for ($ifoo=$istart;$ifoo<count($dirs);$ifoo++) {  // dirs is stable, dirList grows

     $apath=$dirs[$ifoo][0];
     $use_files = array_filter(glob($apath."/*"), 'is_file');

// basic file info for each non-skipped subdir
      $dirInfo=$dirs[$ifoo];
      $nfilesX=dirList_create_getSubdirs_fileInfo($use_files,$skipExts,$dirInfo,$dirList) ;  // dirlist grows (call by reference)

      $nextInDirsFiles++;  // get the next one in dirs

      if ($nextInDirsFiles<count($dirs)-1) {     // not done, so check for timeout
        $checkTime=time();
        $diff=$checkTime-$nowTime  ;
        if ( $diff>$timeAllowed)  {  //  timeout, back to js (save state info first)
           $resumeStatus['dirList']=$dirList;   //dirlist is final output, dirs  (dirCheck) is transient
           $resumeStatus['nextInDirsFiles']=$nextInDirsFiles  ;  // after end
            $amess='Finding files: @ directory '.$nextInDirsFiles.'   of  '.count($dirs).' directories. ';
            $amess.=   ' w/ '.$dirList['.']['totFiles'].' files currently found ';
            return [true,$amess];
         }
      } else {           // done!
           $resumeStatus['nextInDirsFiles']=$nextInDirsFiles  ;  // at end!
           $resumeStatus['dirList']=$dirList  ;  // at end!
      }

  }    //  i e loop over dirs


  return [false,$dirList ];          // [0]=doresume=false means "all done"

}

//===============
// get a list of all the subdirectories under path -- excludin "skips" and "empties".
// Does NOT exclude "no viewables" -- that is determined in a later (create html menu) tsep
//  this is builds dynamically, sort of recursively. dirlist is modifed (called by reference), and so is resumeStatus

function dirList_create_getSubToCheck($path,$skips,&$resumeStatus,$nowTime,$timeAllowed) {
  $skipSubs=[]; $nSkipSubs=0;

  if (!array_key_exists('dirCheck',$resumeStatus)) {  // doesn't exist: get top level subdirs of path
     $path1=rtrim($path,'/').'/*' ;
     $dirs0=glob($path1);
     $dirs=[];

     $aa1=[$path,'',0,0,[]];
     $dirs[]=$aa1;

/*     foreach ($dirs0 as $ij=>$adir) {
        if (!is_dir($adir)) continue;
        $adir_end=dirList_create_getSubdirs_noskip($adir,$skips);
        if ($adir_end===false) {          // don't look at skips subdirecotries
           $skipSubs[]=$adir;
           $nSkipSubs++ ;
           continue;
        }
        $dirs[]=[$adir,$adir_end,0,0,[]];          // fullpath, subdir name, #subdirs, #files (sum of last two =0, this isn't listed)
//        print "<br>strt  $adir";
//        var_dump($dirs);
//       print "<br>rockon ";
     }          // this is the core list of directories  And skips removed.
  */
  
     $resumeStatus['dirCheck']=$dirs;
     $resumeStatus['nextToDoSubs']=0;
     $resumeStatus['nSubs_root']= count($dirs);  // subdirectories that are not skip and not empty
     $resumeStatus['nCheckSubs']=count($dirs) ;  // does NOT include skipsubs
     $resumeStatus['nSkipSubs']=$nSkipSubs ;
     $resumeStatus['skipSubs']=$skipSubs ;

     $resumeStatus['nAllFiles']=0;
     $nextToDoSubs=0;
   } else {
     $nextToDoSubs=$resumeStatus['nextToDoSubs'];
     $dirs=$resumeStatus['dirCheck'];

  }

// got core list. Now "recurse" through
   for (;;) {       // break when no more subdirs
     if ($nextToDoSubs>=count($dirs)) break;    // done them all!
     $apath=$dirs[$nextToDoSubs][0];
     $adir1=$dirs[$nextToDoSubs][1];  // subdir name

     $afiles=glob($apath . "/*") ;     // this is a checkable subdir, so get all  its files and its subdrectories
     $nitems=count($afiles);  // incluses subdirs
     $oksubs=0    ;
     if ($nitems>0) {
       $bsubs=array_filter($afiles,'is_dir');      // find subdiretories of this subdir
       $nsubsB=count($bsubs);             // if > 0,
       $kfiles=$nitems-$nsubsB ;
       $resumeStatus['nAllFiles']+=$kfiles;
       $dirs[$nextToDoSubs][3]=$kfiles;  // # of files
       $okSubNames=[];
       if ($nsubsB>0){
         $okSubs=0;
         foreach ($bsubs as $ij2=>$bdir) {            // don't look at skips subdirecotries
           $bdir_end=dirList_create_getSubdirs_noskip($bdir,$skips);
           if ($bdir_end===false) {
              $skipSubs[]=$bdir;
              $nSkipSubs++ ;
              continue;
           }
           $okSubs++ ;         // # of nonskip subdirs
           $okSubNames[]=$bdir_end  ;
           $dirs[]=[$bdir,$bdir_end,0,0,[]];    // a new subdir  (that will examined in future steps through this growing list
         }          // foreach

         $dirs[$nextToDoSubs][2]=$okSubs;          // does not include skips subdirectories
         $dirs[$nextToDoSubs][4]=$okSubNames;
         $resumeStatus['nCheckSubs']+=$okSubs;
         $resumeStatus['nSkipSubs']=$nSkipSubs;
         $resumeStatus['skipSubs']=$skipSubs;
       }   // nsubsorig

     } // nitems >0

     $nextToDoSubs++;
     if ($nextToDoSubs>=count($dirs)) break;    // done them all!

     $checkTime=time();
     $diff=$checkTime-$nowTime  ;
     if ( $diff>$timeAllowed)  {  //  timeout, back to js (save state info first)
        $resumeStatus['dirCheck']=$dirs;
        $resumeStatus['nextToDoSubs']=$nextToDoSubs  ;  // after end
        return false  ;          // caller will save resumestatus  (called by reference
     }

  }    // infinite loop (for ;;

  $resumeStatus['dirCheck']=$dirs;
  $resumeStatus['dirCheckDone']=1;   // existned of this singals dirCheck is done

  return  $dirs  ;  // the list of subdirs whose files should be examine -- in order to build dirList (some might be dropped if no viewables)
}

//=======================
// add entry $dirList  -- contains summary info on the files in use_files
// will see all files, but only count files with an imgExts or otherExts extension

function  dirList_create_getSubdirs_fileInfo($useFiles,$skipExts,$useme, &$dirList) {

     $nfiles=count($useFiles);  // 'use' able (aka display desired) files in this dir
     $dirList['.']['totDirs']++ ;   // augment count of "subdirs with displayable files"  in this tree
     $infoUseFiles=[];        // count by extention
     $fileDetails=[];
     $nFilesSkip=0; $nFilesUse=0; $nbytes=0;
     foreach ($useFiles as $afile) {
         $dirList['.']['totFiles']++;        // augment count of all  files in tree

        $aext=strtolower(pathInfo($afile,PATHINFO_EXTENSION ));
        if (array_key_exists($aext,$skipExts)) {
            $nFilesSkip++;
            $dirList['.']['totFilesSkip']++;        // augment count of skipped files
        } else {
            $dirList['.']['totFilesUse']++;        // augment count of dissplayable files in tree
            if (!array_key_exists($aext,$infoUseFiles)) $infoUseFiles[$aext]=0;
            $nFilesUse++ ;
            $infoUseFiles[$aext]++;
            $dasize=filesize($afile); $modDate=filemtime($afile);
            $nbytes+=$dasize;
             $dirList['.']['totBytes']+=$dasize;    // augment count of "subdirs with displayable files"  in this tree
            $fileBname=pathInfo($afile,PATHINFO_BASENAME);
            $fileDetails[]=[$fileBname,$dasize,$modDate];
        }
     }

// THIS IS WHAT WE CARE ABOUT ! add info on this dir to dirList, which is returned by reference
     $apath=$useme[0];
   $apath=str_replace('\\','/',$useme[0]);
    $rootPath=$dirList['.']['rootPath']; $ilen=strlen($rootPath);
    $relPath=substr($apath,$ilen+1);
    if ($relPath===false) $relPath='';  // root
    $dirname=$useme[1];   $nsubs=$useme[2];  $subList=$useme[4];
    $dirList[]=['path'=>$apath,'relPath'=>$relPath,'dirname'=>$dirname,'nBytes'=>$nbytes,
                'nFiles'=>$nfiles,'nFilesUse'=>$nFilesUse,'nFilesSkip'=>$nFilesSkip,
                 'nSubs'=>$nsubs,'subs'=>$subList,'byExt'=>$infoUseFiles,'fileDetails'=>$fileDetails] ;

     return $nfiles;
}


//==========
// return name of subdir (i.e.; cc   in /aa/bb/cc). Or false if this is a skip subdir

function   dirList_create_getSubdirs_noskip($adir,$skips=[]) {

   $adir2=str_replace('\\','/',$adir);
   if (strpos($adir,'/')!==false) {     // found a /... just take last element in path
       $oof=explode('/',$adir2);
       $adirUse= array_slice($oof,-1,1)[0];
   } else {     // no / in path used as is
      $adirUse= $adir ;
   }
   $adirUse=trim($adirUse);
   if (count($skips )===0) return $adirUse ;       // no skips to consider

   $skip1=strtolower($adirUse);
   if (array_key_exists($skip1,$skips)) {
      return false  ;// a skips directory (single name, case insensitive)
   }

   return $adirUse; ; // no skip match
}

//================
// create a zip file with a list of files (fully specified
// zipFIleMake is array of ...
//      'real' => string 'D:\wamp\www\photos\goo4\20150718_144139.jpg' (length=43)
//      'sayName' => string 'goo4/20150718_144139.jpg' (length=24)
//      'modDate' => int 1437244900
function zipFileMake($fileList,$amess='') {
   $tname=tempnam(sys_get_temp_dir(), "uploaderC_");
   $zip = new \ZipArchive(); // Load zip library

   $res=$zip->open($tname, \ZIPARCHIVE::CREATE);
   if ($res!==TRUE) {
        echo "ZIP creation failed  ";
        exit;
   }
   foreach ($fileList as $ith=>$afile0) {
      $afilename=$afile0['real'];
      $sayname=$afile0['sayName'];
      $modDate=$afile0['modDate'];
      $zip->addFile($afilename,$sayname); // Adding files into zip
      $zip->setCommentName($afilename,$modDate); // Adding comment ==-- modification date
   }
  $zip->setArchiveComment($amess);
  $zip->close();
  return $tname;
}

//============
// save a piece of a file zipped up)
function filePieceExtract($whereZip,$afile,$nthPiece,$chunkSize) {
     $istart=$nthPiece*$chunkSize;
  //   print "<br>$istart $chunkSize ";
     $stuff=file_get_contents($afile,false,null,$istart,$chunkSize);
     $tname="temp/f_".$whereZip.'_'.$nthPiece.'.tmp';
     $zip = new \ZipArchive(); // Load zip library
     $res=$zip->open($tname, \ZIPARCHIVE::CREATE);
     $zip->addFromString($nthPiece,$stuff);
     $zip->close();
     return $tname;
}


//==============
// curl send to targetUri

function uploadFileToTarget($targetUrl,$dafile,$sayFile,$adata) {

   $request = curl_init($targetUrl);
   $dafile=realpath($dafile);
   $txt_curlfile = curl_file_create($dafile,null,$sayFile )  ;

   $goo=filesize($dafile);

   $adata['fileData']=$txt_curlfile;
   $adata['sayFile']=$sayFile ;
   $ares0=$targetUrl ;

   curl_setopt($request, CURLOPT_POST, true);
   curl_setopt($request,CURLOPT_POSTFIELDS,$adata);
   curl_setopt($request, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($request, CURLOPT_ENCODING, 'identity');   // already zipped, so don't do it again
//   curl_setopt($request, CURLOPT_HEADER, true);

   $ares= curl_exec($request);
   if ($ares===false) {
     $dd=curl_errno($request);
     $rinfo=curl_getinfo($request) ;    // speedDownload is bytes/sec
     $respcode=  curl_getinfo($request,CURLINFO_RESPONSE_CODE );


     print "<br>For $dafile: Curl error: $dd :: " . curl_error($request);
     print "<br>response code: $respcode ";
     return "Curl error: $dd :: " . curl_error($request);
   }
    $rinfo=curl_getinfo($request) ;    // speedDownload is bytes/sec
   $sizeUpload=$rinfo['size_upload'];
   $speedUpload=$rinfo['speed_upload'];
  // $reqSize=$rinfo['request_size'];
 //   $sizeUploaded=  curl_getinfo($request,CURLINFO_SIZE_UPLOAD );

//   $respcode=  curl_getinfo($request,CURLINFO_RESPONSE_CODE );
   curl_close($request);
   return "$ares :: upload: size=".utils\custom_number_format($sizeUpload). ", speed=".utils\custom_number_format($speedUpload)   ;
}
