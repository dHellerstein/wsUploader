<?php
session_start() ;
//  Uploader.
// This is the source side. It provides the user interface (the control panel)
//  and also accesses the "source" directory

use wSurvey\utilsP as utils ;
use wSurvey\getJson as getJs ;
ob_start()  ;

$rootdir=$_SERVER['DOCUMENT_ROOT'] ;
$nowtime=time();
$curDir=getcwd();
$webRoot=dirname($_SERVER['PHP_SELF']);
$sourceServerName=$_SERVER['SERVER_NAME'];

$maxFracFactor=0.95 ;  // fraction of maxfile size to use

require_once($curDir.'/wsurvey.getJson.php');
require_once($curDir.'/wsurvey.utilsP.php');
require_once($curDir.'/wsUploader_dir.php');

// uploaderC library

 $action= getJs\readVar('todo',false);

 $sourceNickname= getJs\readVar('source','');


 if ($action=='basic')   {                  // this is the 2nd step (get some basic info from target server

   $targetUri=getJs\readVar('targetUri','');
   $data=['source'=>$sourceNickname,'todo'=>'basic'];
   $request = curl_init($targetUri);

   curl_setopt($request, CURLOPT_POST, true);

   curl_setopt($request,CURLOPT_POSTFIELDS,$data);

   curl_setopt($request, CURLOPT_RETURNTRANSFER, true);

   $ares0= curl_exec($request);
   print $ares0 ;
   exit;

//   print "ares0= $ares0 ";
//   $ares=json_decode($ares0);
//   getJs\jsonReturn($ares);
 }

 if ($action=='reviewSourceDir') {

   $isresume=getJs\readVar('resume',0);
   $skipSubDirs=getJs\readVar('skipSubDirs',[]);
   $skipExts=getJs\readVar('skipExts',[]);

   $vv=explode(',',$skipSubDirs);
   $skipSubdirsUse=[];
   foreach ($vv as $ii=>$dname) $skipSubdirsUse[strtolower($dname)]=1;

   $vv=explode(',',$skipExts);
   $skipExtsUse=[];
   foreach ($vv as $ii=>$dname) $skipExtsUse[strtolower($dname)]=1;

  $dadir=getJs\readVar('dir');
   $dadiruse=realpath($dadir);
   if ($dadiruse=='') {
     $stuff=['resume'=>false,'content'=>'Problem','status'=>'okay','problem'=>'No such source directory: '.$dadir];
     getJs\jsonReturn($stuff);  // this exits
   }
   if ($isresume==1) {
       $resumeStatus=$_SESSION['uploaderC_resumeStatus'];
   } else {
      $resumeStatus=[];
   }

  $dgot=dirList_create($dadiruse,$skipSubdirsUse,$skipExtsUse,$resumeStatus,2) ;  // done,amess or dirlist

  if ($dgot[0]===false) {   // no mroe resumes
   $_SESSION['uploaderC_resumeStatus']=[];
   $_SESSION['uploaderC_dirList']=$dgot[1];

   $cc=$dgot[1]['.'];
    $stuff=['resume'=>false,'content'=>$cc,'status'=>'okay','problem'=>false];
    getJs\jsonReturn($stuff);  // this exits
  }

// if here, send current status to client, assume a resume
  $_SESSION['uploaderC_resumeStatus']=$resumeStatus;
  $stuff=['resume'=>true,'content'=>$dgot[1] ,'status'=>'okay','problem'=>false];
  getJs\jsonReturn($stuff);

}

if ($action=='menu1') {
  $dirList=$_SESSION['uploaderC_dirList'] ;
  $amess='';
  $amess.='<div class="gradientTan" id="uploadResults"></div>';

  $dbasics=$dirList['.'];
  $rootPath=$dbasics['rootPath'] ;
//  $rootPathLen=strlen($rootPath);
  $amess.=' <div style="background-color:#ddeedd;margin-top:0.5em;max-height:2em;overflow:auto" id="divDirsHeader"></div> ';
  $amess.=' <div class="gradientTan" xstyle="margin-top:0.5em;max-height:12em;overflow:auto" id="divDirsSelected"> ';

  $amess.='<input type="checkbox" value="1" id="uploadOverwrite" title="check to overwrite files on target" > ';
  $amess.='<label for="uploadOverwrite" title="check to overwrite files on target">Overwrite</label> ';
  $amess.='&boxv;';
  $amess.='<input type="checkbox" value="1" id="uploadOverwriteOld" title="check to overwrite files on target ONLY if source file is newer" > ';
  $amess.='<label for="uploadOverwriteOld" title="check to overwrite files on target ONLY if source file is newer">only if old</label> ';
  $amess.='&boxv;';
  $amess.='<input type="checkbox" value="1" id="uploadPause1" title="Pause before uploading" > ';
  $amess.='<label for="uploadPause1" title="Pause before uploading">Pause @start</label> ';
  $amess.='&boxv;';

  $amess.='<input type="button" id="iGoButton" class="goButton" value="Start uploading!" title="click to start uploading ... from source server to target server" onClick="startCopying(this)"> ';
  $amess.=' &boxV; For <span  id="selectedDirsHeader"  title="directories/files/bytes" ';
  $amess.='   data-files="'.$dbasics['totFiles'].'" data-dirs="'.$dbasics['totDirs'].'" data-bytes="'.$dbasics['totBytes'].'" ';
  $amess.='   data-filesnow="'.$dbasics['totFiles'].'" data-dirsnow="'.$dbasics['totDirs'].'" data-bytesnow="'.$dbasics['totBytes'].'" >';
  $amess.='  <tt>'.$rootPath.'</tt>: '.$dbasics['totDirs'].' / '.number_format($dbasics['totFiles']).' / '.utils\custom_number_format($dbasics['totBytes']);
  $amess.= '</span>' ;
  $amess.=' <span style="border:1px dotted gray;font-size:90%;margin:3px 3px 3px 2em;" > <em>Selected: </em>';
  $amess.='<span  id="selectedForCopy" title="directories/files/bytes">'.$dbasics['totDirs'].' / '.number_format($dbasics['totFiles']).' / '.utils\custom_number_format($dbasics['totBytes']).'</span>' ;
  $amess.='</span>';
  $amess.=' <div style="height:12em;overflow:auto"><ul class="linearMenu ">' ;

  $dirList2=[];
  foreach ($dirList as $ith=>$adir) {  // sortable array (minimal values, no '.')
     if ($ith==='.') continue;
     $a1=['ith'=>$ith,'relpath'=>$adir['relPath']];         // ith points back to dirLsit
     $dirList2[]=$a1;
  }
  $dirList3=utils\array_msort($dirList2, ['relpath'=>SORT_ASC],SORT_STRING);    // sort it


  foreach ($dirList3 as $jth=>$adir3) {
     $ith=$adir3['ith'];
     $adir=$dirList[$ith];
     $pathname=$adir['path'];
     $relPath=$adir['relPath'];
     $dirname=$adir['dirname'];
     $nfiles=$adir['nFiles'];
     $nbytes= $adir['nBytes'] ;
     $astyle='' ; $isempty='';
     if ($nfiles==0 && $nbytes==0)  {
        $astyle=' style="border:2px dotted red; " ';
        $isempty=' [this is an empty directory!] ';
     }
     $nbytesSay=utils\custom_number_format($nbytes);
     $ali=' <li '.$astyle.' title="Check to copy this directory, uncheck to skip  '.$isempty.'"  class="linearMenuLi2">';
     $ali.='<label> <input type="checkbox" checked value="1" name="useThisDir" data-path="'.$relPath.'" ';
     $ali.=  '    data-bytes="'.$nbytes.'" data-files="'.$nfiles.'"> ';
     $ali.=' <span title="('.$ith.') '.$relPath.'">'.$relPath.'</span> ';
     $ali.=' <span title="files/bytes" style="font-size:80%;color:blue">'.$nfiles.'/'.$nbytesSay.'</span></label></li>  ' ;
     $amess.=$ali;
  }
  $amess.='</ul> </div>   ' ;
  $amess.='</div>';

  getJs\jsonReturnContent($amess );
}

// build the filelist to iterate through   -- and initialize the needed dirs on the target
if ($action=="senditStep1") {

  $dalogon=$_SESSION['uploaderC_logon'] ;

  $dirlist=$_SESSION['uploaderC_dirList'] ;
  $doems=getJs\readVar('dirs',[]);
  $doemsCheck=[];
  foreach ($doems as $ij=>$ddir) $doemsCheck[$ddir]=1;


  $basics=getJs\readVar('basics',[]);
  $source=getJs\readVar('source','');
  $maxFileSize=$basics['targetLimits']['upload_max_filesize'];

 $fileList=[];
 $dirListUse=[];
 foreach ($dirlist as $ith=>$adir) {
   if ($ith==='.') continue ;
   $arelpath=$adir['relPath'];
   if (!array_key_exists($arelpath,$doemsCheck)) continue ;
   $dirListUse[]=$arelpath;
   foreach ($adir['fileDetails'] as $j1=>$afile) {
     $filename=$afile[0];
     $filesize=$afile[1]  ;
     $filemdate=$afile[2];
     $oof=[$arelpath,$filename,$filesize,$filemdate];
     $fileList[]=$oof;
   }
 }

// this will be uploaded in multiple passes, using zip files (and perhaps inpieces for large files)

 $uploadInfo=['dirList'=>$dirListUse,'fileList'=>$fileList,'nextToDo'=>0,'nDone'=>0,'basics'=>$basics,'nUploaded'=>0];
 $targetUri=$uploadInfo['basics']['targetSpecs']['targetUri'];

 $_SESSION['uploaderC_uploadInfo']=$uploadInfo ;

 // first : initialize dir strucutre on target
   $request = curl_init($targetUri);

   $dirListUse2=implode(',',$dirListUse);
   $data=['todo'=>'setDirs','logon'=>$dalogon,'dirListUse'=>$dirListUse2,'source'=>$sourceNickname];

   curl_setopt($request, CURLOPT_POST, true);

   curl_setopt($request,CURLOPT_POSTFIELDS,$data);

   curl_setopt($request, CURLOPT_RETURNTRANSFER, true);
   $ares= curl_exec($request);
   curl_close($request);
   $ares1=explode(';',$ares);  // exist ;create ;fail
   $aresExist=[]; $aresFail=[];$aresCreate=[];
   if (trim($ares1[0])!=='' )   $aresExist=explode(',',$ares1[0]);
   if (trim($ares1[1])!=='' )   $aresCreate=explode(',',$ares1[1]);
   if (trim($ares1[2])!=='' )   $aresFail=explode(',',$ares1[2]);
   $amess=" Directories on target drive. Created=".count($aresCreate).' | Already exist: '.count($aresExist) ;
   $amess.=' | Unable to create: '.count($aresFail);
   getJs\jsonReturnContent($amess);

}

// Check for existence of files on target (note that dirs have been built by above)

if ($action=="senditStep2") {
  $dalogon=$_SESSION['uploaderC_logon'] ;

  $overwrite=getJs\readVar('overwrite',0);
  $overwriteOld=getJs\readVar('overwriteOld',0);
  if ($overwrite==0) $overwriteOld=0;

  $basics=getJs\readVar('basics',[]);

  $uploadInfo=$_SESSION['uploaderC_uploadInfo']  ;
  $maxFileSize=$uploadInfo['basics']['targetLimits']['upload_max_filesize'];
  $targetUri=$uploadInfo['basics']['targetSpecs']['targetUri'];

  $fileList=$uploadInfo['fileList'];
  $fileCheck=[];
  foreach ($fileList as $ii=>$afile) {    // overkill here, but after removal of existing this should be used
      $a1=$afile[0].'/'.$afile[1];
      $mdate=$afile[3];
      $fileCheck[]="$ii $mdate;".$a1;
  }

 // first : initialize dir strucutre on target
   $request = curl_init($targetUri);
   $fileListUse=implode(',',$fileCheck);
   $data=['todo'=>'checkFiles','logon'=>$dalogon,'fileListUse'=>$fileListUse,'overwrite'=>$overwrite,'overwriteOld'=>$overwriteOld,'source'=>$sourceNickname];

   curl_setopt($request, CURLOPT_POST, true);  // send a file
   curl_setopt($request,CURLOPT_POSTFIELDS,$data);
   curl_setopt($request, CURLOPT_RETURNTRANSFER, true);
   $ares= curl_exec($request);

   curl_close($request);

   $vv=explode(';',$ares) ; //  exist;existOld;notexist
   $existFiles=[];
   if ($vv[0]!='') $existFiles=explode(',',$vv[0]);
   $existFilesOld=[];
   if ($vv[1]!='') $existFilesOld=explode(',',$vv[1]);
   $notExistFiles=[];
   if ($vv[2]!='') $notExistFiles=explode(',',$vv[2]);

   $amess='# of existing files='.count($existFiles).' ('.count($existFilesOld).' are old), non-existing files='. count($notExistFiles) ;

// default is to overwrite
   $removes=0;
   if (count($existFiles)>0 || count($existFilesOld)>0) {
      if ($overwrite==0 )       {  // do not overwrite if file already exists on target
          foreach ($existFiles as $jj=>$jdo) {        // the not old ones are removed from the uploadThese Files list
             unset($fileList[$jdo]);
             $removes++;
          }
          foreach ($existFilesOld as $jj=>$jdo) {     // AND the old ones are removed from the uploadThese Files list
             unset($fileList[$jdo]);
             $removes++;
          }
      }
      if ($overwrite==1 && $overwriteOld==1)       {  // do not overwrite if file already exists on target AND is NOT old
          foreach ($existFiles as $jj=>$jdo) {    // the not old ones   are removed from the uploadThese Files list
             unset($fileList[$jdo]);
             $removes++;
          }                         // the old ones are NOT removed from the "upload these files" list
      }

      $uploadInfo['fileList']=$fileList;             // remove "existing" files
      $_SESSION['uploaderC_uploadInfo']=$uploadInfo   ;
   }
   if ($overwrite==0) $amess.=" |   existing files will <b>not</b> be uploaded " ;
   getJs\jsonReturnContent($amess);

}

// ========
// determine "sets"  (several files zipped up) and "bigs" (files to send in pieces)
if ($action=="senditStep3") {
  $dalogon=$_SESSION['uploaderC_logon'] ;

//  ['dirList'=>$dirListUse,'fileList'=>$fileList,'nextToDo'=>0,'nDone'=>0,'basics'=>basics];

  $overwrite=getJs\readVar('overwrite',0);
  $overwriteOld=getJs\readVar('overwriteOld',0);
  if ($overwrite==0) $overwriteOld=0;
  $basics=getJs\readVar('basics',[]);

  $maxUploadSize=getJs\readVar('maxUploadSize',1);
  $maxUploadSize=$maxUploadSize*1000000;
  $maxFileSizeUse=intval($maxUploadSize*$maxFracFactor);  // be careful about overflow
 
  $uploadInfo=$_SESSION['uploaderC_uploadInfo']  ;
 // $maxFileSize=$uploadInfo['basics']['targetLimits']['upload_max_filesize'];

//  $maxFileSizeUse=intval($maxFileSize*$maxFracFactor);  // be careful about overflow

  $fileList=$uploadInfo['fileList'];
  $nextToDo= $uploadInfo['nextToDo'];
  $ndone= $uploadInfo['nDone'];
  $sets=[]; $bigs=[];   $nbigs=0;$nInSets=0;
  $sizeSet=0;  $aset=[]; $npieces=0;  $bigTotSize=0; $regTotSize=0;
  foreach ($fileList as $ith=>$afile0) {
     $adir=$afile0[0];
     $afile=$afile0[1];
     $asize=$afile0[2];
     if ($asize>$maxFileSizeUse) {        // this file is to be sent in pieces
          $nsets=ceil($asize/$maxFileSizeUse);
          $a1="$ith,$nsets,$asize,$maxFileSizeUse";
          $npieces+=$nsets;
          $bigTotSize+=$asize;
          $bigs[]=$a1;
          $nbigs++;
          continue;
     }
     if ($sizeSet+$asize > $maxFileSizeUse)  {  // this set is big enough
          $sets[]=$sizeSet.','.implode(',',$aset);
          $aset=[];   // reset this set
          $sizeSet=0;
     }
     $regTotSize+=$asize;
     $sizeSet+=$asize;
     $aset[]=$ith ;
     $nInSets++;
  }
  if ($sizeSet>0)  $sets[]=$sizeSet.','.implode(',',$aset);

 $uploadInfo['sets']=$sets;     // ithfile (in  fileList)    (uses ndone and nexttodo that are already set to 0
 $uploadInfo['bigs']=$bigs;       // ithFile, # pieces
 $uploadInfo['bigs_nextToDo']=0;       // ithFile, # pieces
 $uploadInfo['bigs_nextToDoPiece']=0;       // ithFile, # pieces
 $uploadInfo['bigs_ndone']=0;       // ithFile, # pieces
 $uploadInfo['bigs_nUploaded']=0;       // ithFile, # pieces
 $_SESSION['uploaderC_uploadInfo']=$uploadInfo  ;

 $amess="Uploading: ".count($sets).' sets containing '.$nInSets.' files ('.utils\custom_number_format($regTotSize).') ';
 $amess.='  and '.count($bigs).' large files ('.utils\custom_number_format($bigTotSize).") sent in $npieces pieces ";
  getJs\jsonReturnContent($amess);
}

//=========
// send a "set"
if ($action=="senditStep4") {
  $dalogon=$_SESSION['uploaderC_logon'] ;
  $basics=getJs\readVar('basics',[]);

  $uploadInfo=$_SESSION['uploaderC_uploadInfo']  ;
   $sourceRoot=$uploadInfo['basics']['sourceSpecs']['rootPath'];   // 'rootpath' same as 'dir', but use 'rootpath' (it is set in wsuploader_dir.php)
  $targetUri=$uploadInfo['basics']['targetSpecs']['targetUri'];
  $fileList=$uploadInfo['fileList'];
  $sets=$uploadInfo['sets'] ;

  $amess ='<ul class="thinList">' ;
  $nToDo=count($sets);
  if ($nToDo==0) {
     $amess='<br>No sets to copy ';
     $aa=['content'=>$amess ,'end'=>1,'done'=>0,'nToDo'=>$nToDo,'report'=>'No (non-big) files were uploaded'];
     getJs\jsonReturn($aa) ;
  }
  $nextToDo= $uploadInfo['nextToDo'];   // sets!
  $ndone= $uploadInfo['nDone'];
 $nUploaded=$uploadInfo['nUploaded'];

  $doset=$sets[$nextToDo];
  $dosetV=explode(",",$doset);
  $totsize=$dosetV[0];
  $goo1=$nextToDo+1;
  $amess0= "For  set $goo1 (of $nToDo) with size= ". utils\custom_number_format($totsize).", and ".(count($dosetV)-1).' files ';
  $amess=$amess0 ;
  $amess.='<ul class="tightList">';
  $dogFiles=[];
  for ($j=1;$j<count($dosetV);$j++) {
      $j2=$dosetV[$j];
      $afile=$fileList[$j2];
      $dafile=$sourceRoot.'/'.$afile[0].'/'.$afile[1];
      $dafile2=realpath($dafile);
      $aDog=[];
      $aDog['real']=$dafile2;
      $aDog['sayName']=$afile[0].'/'.$afile[1];
      $aDog['modDate']=$afile[3];
      $dogFiles[]=$aDog;

      if (!is_file($dafile2)) {
        $amess.= "<li> MISSING FILE: ".$dafile  ;
      } else {
         $nUploaded++ ;         // assume success
       }
  }
  $zipfile=zipFileMake($dogFiles,$amess0);

  $bdata=['todo'=>'saveSetZip','logon'=>$dalogon,'source'=>$sourceNickname];
  $kzoo=$nextToDo+1;
  $ares= uploadFileToTarget($targetUri,$zipfile,'set_'.$kzoo,$bdata) ;

  $amess.='<li> '.$ares;

   unlink($zipfile);

  $amess.='</ul>';
  $ndone++;
  $nextToDo++;
  $uploadInfo['nextToDo']=$nextToDo ;  // sets!
  $uploadInfo['nDone']=$ndone;
  $uploadInfo['nUploaded']=$nUploaded;
  $_SESSION['uploaderC_uploadInfo']=$uploadInfo  ;
  if ($ndone==$nToDo) {
      $aa=['content'=>$amess,'end'=>1,'done'=>$ndone,'nToDo'=>$nToDo,'report'=>'# of files uploaded='.$nUploaded];
  } else {
      $aa=['content'=>$amess,'end'=>0,'done'=>$ndone,'nToDo'=>$nToDo,'report'=>'# of files uploaded='.$nUploaded];
  }
   getJs\jsonReturn ($aa);
}

//=========
// send a "big"
if ($action=="senditStep5") {
  $dalogon=$_SESSION['uploaderC_logon'] ;
  $basics=getJs\readVar('basics',[]);

  $uploadInfo=$_SESSION['uploaderC_uploadInfo']  ;
  $sourceRoot=$uploadInfo['basics']['sourceSpecs']['rootPath'];   // 'rootpath' same as 'dir', but use 'rootpath' (it is set in wsuploader_dir.php)
  $fileList=$uploadInfo['fileList'];
  $targetUri=$uploadInfo['basics']['targetSpecs']['targetUri'];

  $bigs=$uploadInfo['bigs'] ;
  $nToDo=count($bigs);

  if ($nToDo==0) {
      $aa=['content'=>'No bigs to copy' ,'end'=>1,'done'=>0,'nToDo'=>$nToDo,'report'=>'No big files were uploaded'];
      getJs\jsonReturn($aa) ;
  }

  $nextToDo= $uploadInfo['bigs_nextToDo'];
  $nextToDoPiece= $uploadInfo['bigs_nextToDoPiece'];
  $ndone= $uploadInfo['bigs_ndone'];
  $nUploaded= $uploadInfo['bigs_nUploaded'];

  $dobig=$bigs[$nextToDo];

  $dobigV=explode(",",$dobig);

  $j2=$dobigV[0];
  $npieces=$dobigV[1];
  $fileSize=$dobigV[2];
  $chunkSize=$dobigV[3];
  $afile=$fileList[$j2];
  $relFile=$afile[0].'/'.$afile[1];
  $dafile=$sourceRoot.'/'. $relFile;
  $dafile2=realpath($dafile);
  if (!is_file($dafile2)) {
    $amess.= "MISSING (big) FILE: ".$dafile  ;
  } else {
     $jjz=$nextToDoPiece+1;      // starts at 0
     $jja=$nextToDo+1;
     $amess= "Piece $jjz (of $npieces): $dafile ($jja of $nToDo): " ;
     $amess.=  utils\custom_number_format($chunkSize).' of '.utils\custom_number_format($fileSize).' | ';

     $astart=getJs\readVar('startTime','xx');
     $cfile=filePieceExtract( $astart.'_'.$j2,$dafile2,$nextToDoPiece,$chunkSize);
     $sayFile=$relFile ;

     $adata=['todo'=>'saveSetPiece','logon'=>$dalogon,'piece'=>$jjz,'npieces'=>$npieces,'source'=>$sourceNickname];
     $ares=uploadFileToTarget($targetUri,$cfile,$sayFile,$adata)   ;
     $amess.=$ares;
     unlink($cfile);
  }

  if ($nextToDoPiece <$npieces-1) {
     $nextToDoPiece++;
  } else {
   //  exit;
     $nextToDoPiece=0;
     $nextToDo++;
     $ndone++;
     $nUploaded++ ;
  }

  $uploadInfo['bigs_nextToDo']=$nextToDo ;  // sets!
  $uploadInfo['bigs_nextToDoPiece']=$nextToDoPiece ;  // sets!
  $uploadInfo['bigs_ndone']=$ndone;
  $uploadInfo['bigs_nUploaded']=$nUploaded;

  $_SESSION['uploaderC_uploadInfo']=$uploadInfo  ;
  if ($ndone==$nToDo) {
      $aa=['content'=>$amess,'end'=>1,'done'=>$ndone,'nToDo'=>$nToDo,'piece'=>$nextToDoPiece,'npieces'=>$npieces,'report'=>'# of big files uploaded='.$nUploaded];
  } else {
      $aa=['content'=>$amess,'end'=>0,'done'=>$ndone,'nToDo'=>$nToDo,'piece'=>$nextToDoPiece,'npieces'=>$npieces,'report'=>'# of big files uploaded='.$nUploaded];
  }
   getJs\jsonReturn ($aa);
}

getJs\jsonReturnError('No such action: '.$action);

?>
